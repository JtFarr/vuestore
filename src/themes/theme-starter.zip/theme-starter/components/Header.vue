<template>
  <header>
    Header:
    <router-link :to="localizedRoute('/')">Homepage</router-link>
  </header>
</template>
