// Custom theme related extensions goes here
//
// if you need to have BABEL applied to extensions inside node_modules
// (by default excluded from BABEL) please add ".js" file ext inside require

export default [
  require('theme/extensions/example/index.js')
]
